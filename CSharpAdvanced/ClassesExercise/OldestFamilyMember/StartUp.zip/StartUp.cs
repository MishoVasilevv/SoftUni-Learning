﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            Family family = new Family();

            for (int i = 0; i < n; i++)
            {
                string[] inputArr = Console.ReadLine()
                    .Split(" ");

                Person currentPerson = new Person(inputArr[0], int.Parse(inputArr[1]));

                family.AddMember(currentPerson);
            }

            Person oldestPerson = family.GetOldestMember();

            Console.WriteLine($"{oldestPerson.Name} {oldestPerson.Age}");
        }
    }
}
