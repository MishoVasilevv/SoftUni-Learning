﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IDetainable
    {
        abstract void CanDetain(string number);
    }
}
